package dk.mikkelelvers.legacygames.game.managers;

import dk.mikkelelvers.legacygames.Main;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//TODO (not really):
// - requires 4 people to start a game

public class GameManager {
    public static List<Player> queue = new ArrayList<>();
    public static List<Player> ingame = new ArrayList<>();

    @Getter @Setter
    private boolean status;

    @Getter
    private Player winner;

    public void start() {
        if(status) return;
        status = true;

        queue.removeIf(player -> !player.isOnline());
        // Add the players in 'queue' array to 'ingame' array.
        ingame = new ArrayList<>(queue);

        // Clear all 'ingame' players inventory and armor
        for (Player player : ingame) {
            Main.getInstance().getLobbyHandler().clearInventory(player);
        }
        queue.clear();
        createPillar(Material.BEDROCK, true);
    }

    public void end() {
        status = false;
        createPillar(Material.AIR, false);
        destroyNonBedrockBlocksInRadius();

        for (Player player : ingame) {
            player.setHealth(20);
            Main.getInstance().getLobbyHandler().clearInventory(player);
            player.teleport(Main.getInstance().getLobbyHandler().getSpawn());

            // Give the player items
            player.getInventory().setItem(4, Main.getInstance().getLobbyHandler().JoinEventItem());
            ingame.remove(player);
        }
    }

    public void givingItems() {
        Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getInstance(), () -> {
            for (Player player : ingame) {
                Material randomMaterial = Material.values()[(new Random()).nextInt((Material.values()).length)];
                player.getInventory().addItem(new ItemStack(randomMaterial));
            }
        },0L, 20 * 5);
    }

    public void checker() {
        Bukkit.getScheduler().scheduleSyncRepeatingTask(Main.getInstance(), () -> {
            if (!this.status) {
                if (queue.size() >= 2)
                    start();
            } else if (ingame.size() <= 1) {
                this.winner = ingame.get(0);
                end();
            }

            // Check if 'ingame' players died, or fell to their death
            for (Player player : ingame) {
                if(player.getLocation().getY() <= 55) {
                    Main.getInstance().getLobbyHandler().clearInventory(player);
                    player.teleport(Main.getInstance().getLobbyHandler().getSpawn());
                    // Give the player items
                    player.getInventory().setItem(4, Main.getInstance().getLobbyHandler().JoinEventItem());
                    ingame.remove(player);
                }
            }

        }, 0L,20);
    }

    public void createPillar(Material block, boolean teleport) {
        double increment = (2 * Math.PI) / ingame.size();
        Location center = new Location(Bukkit.getWorld("world"), 1000.0D, 50.0D, 1000.0D);
        World world = center.getWorld();
        int i = 0;
        for (Player player : ingame) {
            double angle = i * increment;
            double x = center.getX() + 0.5D + (ingame.size() * 2) * Math.cos(angle);
            double z = center.getZ() + 0.5D + (ingame.size() * 2) * Math.sin(angle);
            for (int y = 0; y < 15; y++)
                (new Location(world, x, center.getY() + y, z)).getBlock()
                        .setType(block);
            if (teleport)
                player.teleport(new Location(world, x, 65.0D, z));
            i++;
        }
    }

    public void destroyNonBedrockBlocksInRadius() {
        // Your block destruction logic
        Location center = new Location(Bukkit.getWorld("world"), 1000.0D, 50.0D, 1000.0D);
        int radius = ingame.size() * 3;

        for (int x = -radius; x <= radius; x++) {
            for (int y = 0; y < 256; y++) {
                for (int z = -radius; z <= radius; z++) {
                    Location loc = center.clone().add(x, y, z);
                    Block currentBlock = loc.getBlock();
                    if (currentBlock.getType() != Material.BEDROCK) {
                        currentBlock.setType(Material.AIR);
                    }
                }
            }
        }
    }

}