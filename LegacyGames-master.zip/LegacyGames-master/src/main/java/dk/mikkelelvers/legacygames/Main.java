package dk.mikkelelvers.legacygames;

import dk.mikkelelvers.legacygames.commands.AdminCommand;
import dk.mikkelelvers.legacygames.game.listeners.Cancellable;
import dk.mikkelelvers.legacygames.game.listeners.OnJoin;
import dk.mikkelelvers.legacygames.game.listeners.OnQuit;
import dk.mikkelelvers.legacygames.game.listeners.Queue;
import dk.mikkelelvers.legacygames.game.lobby.LobbyHandler;
import dk.mikkelelvers.legacygames.game.managers.GameManager;
import dk.mikkelelvers.legacygames.scoreboard.ScoreboardHandler;
import dk.mikkelelvers.legacygames.utils.StringUtils;
import lombok.Getter;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class Main extends JavaPlugin {

    @Getter
    private static Main instance;

    @Getter
    private ConsoleCommandSender log = getServer().getConsoleSender();
    @Getter
    private ScoreboardHandler scoreboardHandler;
    @Getter
    private GameManager gameManager;
    @Getter
    private LobbyHandler lobbyHandler;
    /*
        external plugin dependencies
     */
    @Override
    public void onEnable() {
        //Pure visual for admins
        long startTime = System.currentTimeMillis();
        log.sendMessage("§aEnabling the plugin..");

        instance = this;

        //Initialize handlers, listeners and commands
        log.sendMessage("§aLoading all handlers and commands..");
        this.loadHandlers();
        this.loadCommands();
        this.loadListeners();

        //Pure visual for admins
        long finishTime = System.currentTimeMillis();
        String formattedTime = StringUtils.formatNum((finishTime - startTime) / 1000f);
        log.sendMessage("§aPlugin has successfully been enabled! (Took "+formattedTime+"s)");
    }

    @Override
    public void onDisable() {
        log.sendMessage("§cDisabling the plugin..");
    }

    private void loadHandlers() {
        this.scoreboardHandler = new ScoreboardHandler();
        this.gameManager = new GameManager();
        this.lobbyHandler = new LobbyHandler();

        this.gameManager.givingItems();
        this.gameManager.checker();
    }

    private void loadCommands() {
        Bukkit.getPluginCommand("admincommand").setExecutor(new AdminCommand());
    }

    private void loadListeners() {
        Bukkit.getPluginManager().registerEvents(new Cancellable(),this);
        Bukkit.getPluginManager().registerEvents(new OnJoin(),this);
        Bukkit.getPluginManager().registerEvents(new OnQuit(),this);
        Bukkit.getPluginManager().registerEvents(new Queue(),this);

    }
}