package dk.mikkelelvers.legacygames.commands;

import dk.mikkelelvers.legacygames.Main;
import dk.mikkelelvers.legacygames.game.managers.GameManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AdminCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("This command can only be executed by a player.");
            return false;
        }

        Player player = (Player) sender;

        if (args.length < 1) {
            sender.sendMessage("Usage: /testcommand <argument>");
            return false;
        }

        Main plugin = Main.getInstance();
        if (plugin == null) {
            sender.sendMessage("Error: Plugin instance not found.");
            return false;
        }

        GameManager gameManager = plugin.getGameManager();
        if (gameManager == null) {
            sender.sendMessage("Error: Game manager not found.");
            return false;
        }

        if(args[0].equalsIgnoreCase("1")) {
            gameManager.createPillar(Material.BEDROCK, false);
        } else if(args[0].equalsIgnoreCase("2")) {
            gameManager.createPillar(Material.AIR, false);
        } else if (args[0].equalsIgnoreCase("3")) {
            gameManager.destroyNonBedrockBlocksInRadius();
            sender.sendMessage("done");
        }
        return true;
    }

}
