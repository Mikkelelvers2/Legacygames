package dk.mikkelelvers.legacygames.game.listeners;

import dk.mikkelelvers.legacygames.game.managers.GameManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryInteractEvent;

public class Cancellable implements Listener {

    @EventHandler
    public void InventoryInteract(InventoryInteractEvent e) {
        Player player = (Player) e.getWhoClicked();
        if(player.isOp()) return;

        if(!GameManager.ingame.contains(player)) {
            e.setCancelled(true);
        }
    }
}
