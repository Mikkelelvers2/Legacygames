package dk.mikkelelvers.legacygames.scoreboard;

import lombok.Getter;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;

public class PlayerScoreboard {

    @Getter
    private final Player player;
    private ScoreboardUtil scoreboard;

    public PlayerScoreboard(Player player) {
        this.player = player;
    }

    public void createScoreboard() {
        this.scoreboard = new ScoreboardUtil("");
        this.scoreboard.send(player);
    }

    public void deleteScoreboard() {
        if(this.scoreboard == null) return;
        this.scoreboard.getScoreboard().getObjective(DisplaySlot.SIDEBAR).unregister();
    }

    public void updateScoreboard() {
        this.scoreboard.add("§fRank:",13);

        this.scoreboard.update();
    }
}
