package dk.mikkelelvers.legacygames.game.listeners;

import dk.mikkelelvers.legacygames.Main;
import dk.mikkelelvers.legacygames.game.managers.GameManager;
import dk.mikkelelvers.legacygames.utils.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;

public class Queue implements Listener {

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        Player player = e.getPlayer();

        if (player.getItemInHand().getType().equals(Material.INK_SACK)) {
            if (!GameManager.queue.contains(player)) {
                player.getInventory().setItem(4, Main.getInstance().getLobbyHandler().LeaveEventItem());
                GameManager.queue.add(player);
                Bukkit.broadcastMessage(String.valueOf(GameManager.queue.size()));
                player.sendMessage(StringUtils.colorize("&2[!] &aDu kommer med i næste runde."));
            } else {
                player.getInventory().setItem(4, Main.getInstance().getLobbyHandler().JoinEventItem());
                GameManager.queue.remove(player);
                player.sendMessage(StringUtils.colorize("&4[!] &cDu vil ikke længere komme med i det næste spil."));
            }
        }
    }
}
