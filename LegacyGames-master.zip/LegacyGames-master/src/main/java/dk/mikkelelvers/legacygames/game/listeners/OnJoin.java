package dk.mikkelelvers.legacygames.game.listeners;

import dk.mikkelelvers.legacygames.Main;
import dk.mikkelelvers.legacygames.game.managers.GameManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class OnJoin implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();
        e.setJoinMessage("");

        // Checks if player is in the game
        if(GameManager.ingame.contains(player)) {
            GameManager.ingame.remove(player);
        }
        // Teleport the player to spawn
        player.teleport(Main.getInstance().getLobbyHandler().getSpawn());
        Main.getInstance().getLobbyHandler().clearInventory(player);

        // Give the player items
        player.getInventory().setItem(4, Main.getInstance().getLobbyHandler().JoinEventItem());
    }
}