package dk.mikkelelvers.legacygames.game.lobby;

import dk.mikkelelvers.legacygames.utils.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class LobbyHandler {

    public ItemStack JoinEventItem() {
        ItemStack item = new ItemStack(Material.INK_SACK, 1, (short) 10);
        ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(StringUtils.colorize("&aJoin"));
        item.setItemMeta(meta);
        return item;
    }

    public ItemStack LeaveEventItem() {
        ItemStack item = new ItemStack(Material.INK_SACK, 1, (short) 8);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(StringUtils.colorize("&cLeave"));
        item.setItemMeta(meta);
        return item;
    }

    public void clearInventory(Player player) {
        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
    }

    public Location getSpawn() {
        return new Location(Bukkit.getWorld("world"), 0, 50, 0);
    }
}
