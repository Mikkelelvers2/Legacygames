package dk.mikkelelvers.legacygames.utils;

import net.md_5.bungee.api.ChatColor;
import java.text.NumberFormat;

public class StringUtils {

    private static final NumberFormat numberFormat = NumberFormat.getNumberInstance();

    static {
        numberFormat.setMaximumFractionDigits(5);
    }

    public static String formatNum(double input) {
        return numberFormat.format(input);
    }

    public static String colorize(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
